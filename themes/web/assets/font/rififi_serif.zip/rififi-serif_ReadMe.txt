Hi, thanx for downloading Rififi Serif !

Free for your personnal use only.
If you want to use/embed it for a commercial project, please consider buying a license.

Don't hesitate to send me samples of your work, made with this font, it's always apreciated ! =) 

You're not authorized to modify, distribute, or sell this font.
Please always keep this Read_me file, the TTF & EOT files, the HTML file, and the Image with the font.

Damien Gosset
daaams[AT]laposte.net  |  http://www.sweeep.fr

-----------------------------------------------------------------------------------------------------

Merci d'avoir t�l�charg� Rififi Serif !

Utilisation gratuite � but personnel uniquement.
Si vous souhaitez utiliser cette police � des fins commerciales, merci d'acheter une licence.

N'h�sitez pas � m'envoyer vos boulots faits avec ma police, �a m'interesse ! =)

Vous n'avez pas le droit de modifier, de distribuer, ni de vendre cette police.
Merci de toujours laisser ce fichier Read_Me, les fichiers TTF et OET, le fichier HTML, et l'Image avec la police.

Damien Gosset
daaams[AT]laposte.net  |  http://www.sweeep.fr